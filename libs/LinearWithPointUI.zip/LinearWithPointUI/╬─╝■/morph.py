
from . import projectanarchy

class 类(projectanarchy.anarchymorph.morphfile):
    def __init__(self, bp): super().__init__(bp)

