


class Pose: pass