

class FBXHeaderExtension: pass