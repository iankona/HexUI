
class NodeAttribute: pass