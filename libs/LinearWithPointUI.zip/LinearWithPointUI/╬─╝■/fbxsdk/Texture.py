


class Texture: pass