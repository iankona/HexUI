

class LayerElementNormal: pass