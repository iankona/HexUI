

class LayerElementColor: pass