


class LayerElementTangent: pass