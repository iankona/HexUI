


class AnimationStack: pass