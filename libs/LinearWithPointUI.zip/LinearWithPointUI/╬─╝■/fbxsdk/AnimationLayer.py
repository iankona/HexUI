

class AnimationLayer: pass