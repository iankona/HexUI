def 函数(flag, size, version, bp):
    match version:
        case 2: pass
        case 4: pass  # 古剑2
