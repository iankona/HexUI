def 函数(bp):
    return bp.readchar(bp.readuint32())