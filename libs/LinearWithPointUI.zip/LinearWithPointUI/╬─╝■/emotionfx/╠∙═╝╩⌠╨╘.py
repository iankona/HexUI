def 函数(bp):
    pass