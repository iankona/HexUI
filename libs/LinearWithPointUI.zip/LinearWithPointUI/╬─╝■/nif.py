from . import gamebryo


class 类(gamebryo.gamebryonif.niffile):
    def __init__(self, bp): super().__init__(bp)

