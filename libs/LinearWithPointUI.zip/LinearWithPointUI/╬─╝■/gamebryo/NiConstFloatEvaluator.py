

class NiConstFloatEvaluator:
    def __init__(self, bp, kffile):
        pass