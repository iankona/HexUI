class NiMorphMeshModifier:
    def __init__(self, bp, niffile):
        pass    