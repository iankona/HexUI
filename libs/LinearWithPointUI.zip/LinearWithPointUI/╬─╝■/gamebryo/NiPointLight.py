
class NiPointLight:
    def __init__(self, bp, niffile):
        pass