
class NiZBufferProperty:
    def __init__(self, bp, niffile):
        pass