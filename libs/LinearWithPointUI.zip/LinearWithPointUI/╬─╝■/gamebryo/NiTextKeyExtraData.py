class NiTextKeyExtraData:
    def __init__(self, bp, niffile):
        pass