class NiInstancingMeshModifier:
    def __init__(self, bp, niffile):
        pass