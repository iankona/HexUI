

class NiFloatsExtraData:
    def __init__(self, bp, niffile):
        pass