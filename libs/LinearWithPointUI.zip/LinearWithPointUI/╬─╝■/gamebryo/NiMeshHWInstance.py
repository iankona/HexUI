class NiMeshHWInstance:
    def __init__(self, bp, niffile):
        pass