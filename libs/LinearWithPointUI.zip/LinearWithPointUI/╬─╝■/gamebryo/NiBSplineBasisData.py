

class NiBSplineBasisData:
    def __init__(self, bp, kffile):
        pass