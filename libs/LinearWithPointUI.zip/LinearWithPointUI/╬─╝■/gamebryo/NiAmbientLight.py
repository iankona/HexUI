
class NiAmbientLight:
    def __init__(self, bp, niffile):
        pass