class NiBSplineData:
    def __init__(self, bp, kffile):
        pass