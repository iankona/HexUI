class NiVertexColorProperty:
    def __init__(self, bp, niffile):
        pass    