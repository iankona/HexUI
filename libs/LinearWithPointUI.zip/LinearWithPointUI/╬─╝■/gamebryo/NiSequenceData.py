
class NiSequenceData:
    def __init__(self, bp, kffile):
        self.name = None


    def 读取成员(self, bp, kffile):
        pass
        # self.name = kffile.名称列表[bp.readu32()]
        # numID = bp.readu32()
        # ID列表 = [bp.readu32() for x in range(numID)] # NiTextKeyExtraData