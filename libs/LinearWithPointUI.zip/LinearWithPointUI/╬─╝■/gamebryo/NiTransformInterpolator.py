class NiTransformInterpolator:
    def __init__(self, bp, niffile):
        pass