from . import emotionfx

class 类(emotionfx.xsm.类):
    def __init__(self, bp): super().__init__(bp)