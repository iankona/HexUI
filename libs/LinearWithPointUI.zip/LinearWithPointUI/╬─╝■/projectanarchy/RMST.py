class RMST:
    def __init__(self, bp):
        self.read_block_data(bp)


    def read_block_data(self, bp):
        pass