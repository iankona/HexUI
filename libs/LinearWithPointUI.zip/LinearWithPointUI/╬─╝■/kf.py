from . import gamebryo


class 类(gamebryo.gamebryokf.kffile):
    def __init__(self, bp): super().__init__(bp)