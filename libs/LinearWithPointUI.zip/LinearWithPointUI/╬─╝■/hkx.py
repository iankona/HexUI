from . import havok

class 类(havok.havokhkx.hkxfile):
    def __init__(self, bp): super().__init__(bp)