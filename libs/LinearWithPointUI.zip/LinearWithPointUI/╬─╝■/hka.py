from . import havok

class 类(havok.havokhka.hkafile):
    def __init__(self, bp): super().__init__(bp)





