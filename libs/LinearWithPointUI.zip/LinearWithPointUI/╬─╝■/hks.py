from . import havok

class 类(havok.havokhks.hksfile):
    def __init__(self, bp): super().__init__(bp)