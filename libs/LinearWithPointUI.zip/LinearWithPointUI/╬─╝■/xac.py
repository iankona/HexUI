from . import emotionfx

class 类(emotionfx.xac.类):
    def __init__(self, bp): super().__init__(bp)