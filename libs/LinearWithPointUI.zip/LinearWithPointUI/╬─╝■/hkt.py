


from . import havok

class 类(havok.havokhkt.hktfile):
    def __init__(self, bp): super().__init__(bp)