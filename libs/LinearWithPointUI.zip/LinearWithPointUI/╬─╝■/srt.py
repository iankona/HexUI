from . import speedtree

class 类(speedtree.srt.类):
    def __init__(self, bp): super().__init__(bp)