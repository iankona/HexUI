from . import projectanarchy

class 类(projectanarchy.anarchyvmesh.vmeshfile):
    def __init__(self, bp): super().__init__(bp)