


latent_model = None

clips = []
unets = []
vaes = []
embedding = []
loras = []